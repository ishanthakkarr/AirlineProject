export const taskConstants = {
    TASK_REQUEST: "TASK_REQUEST",
    TASK_SUCCESS: "TASK_SUCCESS",
    TASK_FAILURE: "TASK_FAILURE"
  };