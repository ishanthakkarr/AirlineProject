import { taskConstants } from "../actions/constants";

const initState = {
  loading: false,
  error: null,
  totalPassengers:0,
  totalPages:0,
  taskData: [],
};

export default (state = initState, action) => {
  switch (action.type) {
    case taskConstants.TASK_REQUEST:
      state = {
        ...state,
        loading: true,
      };
      break;
    case taskConstants.TASK_SUCCESS:
      state = {
        ...state,
        loading: false,
        totalPassengers:action.payload.totalPassengers,
        totalPages:action.payload.totalPages,
        taskData:action.payload.data
      };
      break;
    case taskConstants.TASK_FAILURE:
      state = {
        ...state,
        loading: false,
      };
      break;
  }

  return state;
};
