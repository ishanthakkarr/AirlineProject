import axios from "axios";
import { taskConstants } from "./constants";
export const getTaskData = (page,size) => {
  return async (dispatch) => {
    let res;
    try {
      dispatch({ type: taskConstants.TASK_REQUEST });
      res = await axios.get(
        `https://api.instantwebtools.net/v1/passenger?page=${page}&size=${size}`
      );
    //   debugger;
      if (res.status === 200) {
        const { totalPassengers, totalPages, data } = res.data;
        // debugger;
        dispatch({
          type: taskConstants.TASK_SUCCESS,
          payload: {
            totalPassengers,
            totalPages,
            data
          },
        });
      } else {
        const { error } = res.data;
        dispatch({ type: taskConstants.TASK_FAILURE, payload: { error } });
      }
    } catch (error) {
      const { data } = error.response;
      dispatch({
        type: taskConstants.TASK_FAILURE,
        payload: { error: data.error },
      });
    }
  };
};
