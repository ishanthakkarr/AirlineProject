import React from "react";
import TaskComponent from './components/TaskComponent'
function App() {
  return <TaskComponent />
}

export default App;
