import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Table from "react-bootstrap/Table";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import Pagination from "../Pagination";
import { getTaskData } from "../../actions";
const TaskComponent = (props) => {
  const dispatch = useDispatch();
  const taskReducer = useSelector((state) => state.task);
  const [userData, setUserData] = useState([]);
  const [show, setShow] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [pageSize, setPageSize] = useState(20);
  const [totalRows, setTotalRows] = useState(0);

  useEffect(() => {
    dispatch(getTaskData(currentPage,pageSize));
  }, []);

  useEffect(() => {
    setTotalRows(taskReducer?.totalPassengers);
    setCurrentPage(1);
  },[taskReducer?.totalPages])

  const handleClose = () => {
    setShow(false);
    setUserData([]);
  };
  const handleShow = () => setShow(true);

  const returnUserData = (userid) => {
    let user_Data =
      taskReducer &&
      taskReducer.taskData.filter((task) => {
        return task._id == userid;
      });
    debugger;
    setUserData(user_Data[0].airline);
    // console.log("user_Data[0] ===> ",user_Data[0]);
  };

  const onCheckAirlineButtonClick = (userid) => {
    returnUserData(userid);
    handleShow();
  };

  const onChange = (event) => {
    setCurrentPage(event.target.value);
    dispatch(getTaskData(event.target.value,pageSize));
  
};

  return (
    <div>
      {taskReducer &&
        Array.isArray(taskReducer.taskData) &&
        taskReducer.taskData.length > 0 && (
          <Pagination
            currentPage={currentPage}
            pageSize={pageSize}
            totalRows={totalRows}
            onClickPre={(pageNo) => {
              onChange({
                target: {
                  name: "currentPage",
                  value: pageNo,
                },
              });
            }}
            onClickNext={(pageNo) => {
              onChange({
                target: {
                  name: "currentPage",
                  value: pageNo,
                },
              });
            }}
            onClickPage={(pageNo) => {
              onChange({
                target: {
                  name: "currentPage",
                  value: pageNo,
                },
              });
            }}
          ></Pagination>
        )}
      <Table striped bordered hover style={{ margin: "5px" }}>
        <thead>
          <tr>
            <th style={{ textAlign: "center" }}>User name</th>
            <th style={{ textAlign: "center" }}>Total number of trips</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {taskReducer &&
            Array.isArray(taskReducer.taskData) &&
            taskReducer.taskData.map((task) => (
              <tr>
                <td style={{ textAlign: "center" }}>{task.name}</td>
                <td style={{ textAlign: "center" }}>{task.trips}</td>
                <td style={{ textAlign: "center" }}>
                  <Button onClick={() => onCheckAirlineButtonClick(task._id)}>
                    Check Airline
                  </Button>
                </td>
              </tr>
            ))}
        </tbody>
      </Table>

      {/* modal */}
      <Modal
        show={show}
        onHide={handleClose}
        backdrop="static"
        keyboard={false}
        size="lg"
      >
        <Modal.Header closeButton>
          <Modal.Title>User airline data</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Table striped bordered hover style={{ margin: "5px" }}>
            <thead>
              <tr>
                <th style={{ textAlign: "center" }}>Airline name</th>
                <th style={{ textAlign: "center" }}>Country</th>
                <th style={{ textAlign: "center" }}>Logo</th>
                <th style={{ textAlign: "center" }}>Slogan</th>
                <th style={{ textAlign: "center" }}>Head quaters</th>
                <th style={{ textAlign: "center" }}>Website</th>
                <th style={{ textAlign: "center" }}>Established</th>
              </tr>
            </thead>
            <tbody>
              {userData &&
                userData.map((airlineData) => (
                  <tr>
                    <td style={{ textAlign: "center" }}>{airlineData.name}</td>
                    <td style={{ textAlign: "center" }}>
                      {airlineData.country}
                    </td>
                    <td style={{ textAlign: "center" }}>
                      {
                        <img
                          src={airlineData.logo}
                          height="50"
                          width="50"
                        ></img>
                      }
                    </td>
                    <td style={{ textAlign: "center" }}>
                      {airlineData.slogan}
                    </td>
                    <td style={{ textAlign: "center" }}>
                      {airlineData.head_quaters}
                    </td>
                    <td style={{ textAlign: "center" }}>
                      {airlineData.website}
                    </td>
                    <td style={{ textAlign: "center" }}>
                      {airlineData.established}
                    </td>
                  </tr>
                ))}
            </tbody>
          </Table>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default TaskComponent;
