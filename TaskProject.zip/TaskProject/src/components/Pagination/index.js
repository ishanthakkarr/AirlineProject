import React from 'react';
import ArrowImg from "../../images/arrow.svg";
import './style.css'

const Pagination = props => {
    const totalpages = parseInt(props.totalRows / props.pageSize) + (props.totalRows % props.pageSize !=0 ? 1 : 0); 
    let base = parseInt(5 / 2);
    let rangeMin = props.currentPage - base;
    let rangeMax = props.currentPage + base;

    let items=[];
    for(let i=1; i<=totalpages; i++) {
        if(i>=rangeMin && i<=rangeMax) {
            items.push(
                <li className={"page-item " + (props.currentPage==i ? "active":"")}>
                    <a className="page-link" onClick={()=>props.onClickPage(i)}>{i}</a>
                </li>
            )
        }
    }
    return (
        <ul className="pagination justify-content-end">
            <li className={"page-item " + (props.currentPage==1 ? "disabled":"")}>
                <a className="page-link prev-btn" onClick={()=>props.onClickPre(props.currentPage-1)}>
                    <img src={ArrowImg} alt="" />
                </a>
            </li>
            {items}
            <li className={"page-item " + (props.currentPage==totalpages ? "disabled":"")}>
                <a className="page-link nxt-btn" onClick={()=>props.onClickNext(props.currentPage+1)}>
                    <img src={ArrowImg} alt="" />
                </a>
            </li>
        </ul>
    )
}

export default Pagination;  