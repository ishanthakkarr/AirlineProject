import taskReducer from './task.reducer';


import { combineReducers } from 'redux'

const rootReducer = combineReducers({
    task: taskReducer
});

export default rootReducer;